<?php return array(
    'root' => array(
        'name' => 'project/plugin',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => '73a69886f0de6b1f8992ffeae23691eb36560bcc',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'project/plugin' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => '73a69886f0de6b1f8992ffeae23691eb36560bcc',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
